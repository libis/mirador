<?php
 
header("access-control-allow-methods:GET,POST,PUT,DELETE,HEAD,OPTIONS");
header("access-control-allow-origin:*");
header("access-control-expose-headers:X-Requested-With,X-jsonblob,X-Hello-Human,Location,Date,Content-Type,Accept,Origin");
header("cf-ray:3b0b68d41f7e4427-BRU");
header("content-type:application/json; charset=utf-8");
header("accept:application/json");

// get the HTTP method, path and body of the request
$method = $_SERVER['REQUEST_METHOD'];
$blobPath = $_SERVER['PATH_INFO'];
echo($blobpath);
echo($method);
?>
