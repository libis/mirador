describe('AnnotationTooltip', function() {

  beforeEach(function() {

  });

  afterEach(function() {

  });

  xdescribe('Initialization', function() {
    it('should initialize', function() {

    });
  });

  xdescribe('showEditor', function() {

  });
  
  xdescribe('initializeViewerUpgradableToEditor', function() {

  });

  xdescribe('removeAllEvents', function() {

  });

  xdescribe('addViewerEvents', function() {

  });

  xdescribe('addEditorEvents', function() {

  });

  xdescribe('showViewer', function() {

  });

  xdescribe('setTooltipContent', function() {

  });

  xdescribe('getViewerContent', function() {

  });

  xdescribe('freezeQtip', function() {

  });

  xdescribe('unFreezeQtip', function() {

  });
});
