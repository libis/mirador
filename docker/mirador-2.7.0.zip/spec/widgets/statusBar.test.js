describe('WidgetStatusBar', function() {
  var subject;
  beforeEach(function() {
    subject = new Mirador.WidgetStatusBar({})
  });

  afterEach(function() {
    delete subject;
  });

  describe('Initialization', function() {
    it('should initialize', function() {
      expect(true).toBe(true); //Force beforeEach() setup to run
    });
  });

  xdescribe('', function() {

  });
}); 
