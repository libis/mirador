window.MiradorExample = {};

(function ($) {

  jQuery(document).ready(function () {
    Mirador($.config_1);
    Mirador($.config_2);
  });

})(MiradorExample);
