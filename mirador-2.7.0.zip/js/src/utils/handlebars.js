(function($) {

  $.Handlebars = (function() {
    return Handlebars.create();
  })();

}(Mirador));
