(function ($) {
  $.WidgetStatusBar = function WidgetStatusBar(options) {
    jQuery.extend(true, this, {

    }, $.DEFAULT_SETTINGS, options);
  };
}(Mirador));
