describe('Endpoint', function() {

  beforeEach(function() {

  });

  afterEach(function() {

  });

  xdescribe('Initialization', function() {
    it('should initialize', function() {

    });
  });

  xdescribe('search', function() {

  });

  xdescribe('deleteAnnotation', function() {

  });

  xdescribe('update', function() {

  });

  xdescribe('create', function() {

  });

  xdescribe('set', function() {

  });

  xdescribe('getAnnotationInOA', function() {

  });

  xdescribe('getAnnotationInEndpoint', function() {

  });
}); 
