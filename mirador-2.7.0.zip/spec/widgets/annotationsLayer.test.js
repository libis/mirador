describe('AnnotationsLayer', function() {

  beforeEach(function() {

  });

  afterEach(function() {

  });

  xdescribe('Initialization', function() {
    it('should initialize', function() {

    });
  });

  xdescribe('listenForActions', function() {

  });

  xdescribe('bindEvents', function() {

  });

  xdescribe('createRenderer', function() {

  });

  xdescribe('updateRenderer', function() {

  });

  xdescribe('modeSwitch', function() {

  });

  xdescribe('enterDisplayAnnotations', function() {

  });

  xdescribe('enterEditAnnotations', function() {

  });

  xdescribe('enterDefault', function() {

  });
}); 
