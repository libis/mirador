describe('Hud', function() {

  beforeEach(function() {

  });

  afterEach(function() {

  });

  xdescribe('Initialization', function() {
    it('should initialize', function() {

    });
  });

  xdescribe('bindEvents', function() {

  });

  xdescribe('createStateMachine', function() {

  });
}); 
